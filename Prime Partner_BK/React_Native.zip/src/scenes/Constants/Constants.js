// const baseUrl='https://mobileapp.accentivrewards.in/DRL/PrimaWebService.asmx';
const baseUrl='https://mobileapp.accentivrewards.com/DRL/PrimaWebService.asmx';
export default baseUrl;